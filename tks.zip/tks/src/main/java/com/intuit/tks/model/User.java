package com.intuit.tks.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "users")
public class User {

    @Id
    private String id;          // Use String or ObjectId
    private String username;    // Username of the user

    public User(String id, String username) {
        this.id = id;
        this.username = username;
    }
    public User() {

    }
}