package com.intuit.tks.exception;

public class CommentNotFoundException extends RuntimeException{
    public CommentNotFoundException(String commentId) {
        super("Comment not found: " + commentId);
    }
}