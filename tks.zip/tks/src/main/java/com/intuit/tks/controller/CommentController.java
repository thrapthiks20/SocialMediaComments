package com.intuit.tks.controller;

import com.intuit.tks.model.Comment;
import com.intuit.tks.model.User;
import com.intuit.tks.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.intuit.tks.constants.ApiConstants.*;

@RestController
@RequestMapping(POST_COMMENT_BASE_URL)
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping(POST_ID_WITH_COMMENTS)
    public Comment postComment(@PathVariable String postId, @RequestBody Comment comment){
        return commentService.postComment(postId, comment);
    }

    @GetMapping(POST_ID_WITH_COMMENTS)
    public List<Comment> getComments(@PathVariable String postId, @RequestParam int page, @RequestParam int limit){
        return commentService.fetchComments(postId, page, limit);
    }

    @GetMapping(COMMENTS_WITH_REPLIES)
    public List<Comment> getReplies(@PathVariable String commentId, @RequestParam int page, @RequestParam int limit){
        return commentService.fetchReplies(commentId, page, limit);
    }

    @PostMapping(COMMENTS_WITH_LIKES)
    public Comment likeComment(@PathVariable String commentId, @RequestBody String userId){
        return commentService.likeComment(commentId, userId);
    }

    @PostMapping(COMMENTS_WITH_DISLIKES)
    public Comment dislikeComment(@PathVariable String commentId, @RequestBody String userId){
        return commentService.dislikeComment(commentId, userId);
    }

    @GetMapping(COMMENTS_WITH_LIKES)
    public List<User> getLikedUser(@PathVariable String commentId){
        return commentService.getLikedUsers(commentId);
    }

    @GetMapping(COMMENTS_WITH_DISLIKES)
    public List<User> getDislikedUser(@PathVariable String commentId){
        return commentService.getDisLikedUsers(commentId);
    }
}
