package com.intuit.tks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TksApplication {

	public static void main(String[] args) {
		SpringApplication.run(TksApplication.class, args);
	}

}
