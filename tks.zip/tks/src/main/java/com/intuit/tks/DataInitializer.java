package com.intuit.tks;

import com.intuit.tks.model.User;
import com.intuit.tks.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void run(String... args) throws Exception {

        // Create a list of sample users
        List<User> users = Arrays.asList(
                new User("1", "Rachel"),
                new User("2", "Monica"),
                new User("3", "Phoebe"),
                new User("4", "Ross"),
                new User("5", "Chandler"),
                new User("6", "Joey")
        );

        // Save all users to the repository
        userRepository.saveAll(users);
        System.out.println("Sample users populated!");
    }
}
