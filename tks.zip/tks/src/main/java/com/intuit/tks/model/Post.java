package com.intuit.tks.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@Document(collection = "posts")
public class Post {

    @Id
    private String id;  // You can use String or ObjectId
    private String title;
    private String content;
    private List<Comment> comments = new ArrayList<>(); // Initialize the comments list

}