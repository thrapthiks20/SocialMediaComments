package com.intuit.tks.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@Document(collection = "comments")
public class Comment {

    @Id
    private String id;          // Use String or ObjectId
    private String postId;      // ID of the post this comment belongs to
    private String parentId;    // ID of the parent comment, if any
    private String content;      // Content of the comment
    private List<String> likes = new ArrayList<>();      // Array of user IDs who liked the comment
    private List<String> dislikes = new ArrayList<>();   // Array of user IDs who disliked the comment
    private List<Comment> replies = new ArrayList<>();   // Array of replies to this comment
}