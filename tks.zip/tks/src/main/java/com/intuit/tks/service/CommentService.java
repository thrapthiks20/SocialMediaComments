package com.intuit.tks.service;

import com.intuit.tks.exception.CommentNotFoundException;
import com.intuit.tks.model.Comment;
import com.intuit.tks.model.User;
import com.intuit.tks.repository.CommentRepository;
import com.intuit.tks.repository.PostRepository;
import com.intuit.tks.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private UserRepository userRepository;

    public Comment postComment(String postId, Comment comment){
        comment.setPostId(postId);
        return commentRepository.save(comment);
    }

    public List<Comment> fetchComments(String postId, int page, int limit){
        int skip = page * limit;
        Pageable pageable = PageRequest.of(page, limit);
        List<Comment> comments = commentRepository.findByPostId(postId);
        return comments.stream()
                .skip(pageable.getOffset())
                .limit(pageable.getPageSize())
                .toList();
    }

    public List<Comment> fetchReplies(String commentId, int page, int limit){
        Pageable pageable = PageRequest.of(page, limit);
        List<Comment> replies = commentRepository.findByParentId(commentId);
        return replies.stream()
                .skip(pageable.getOffset())
                .limit(pageable.getPageSize())
                .toList();
    }

    public Comment likeComment(String commentId, String userId) {
        Optional<Comment> optComment = commentRepository.findById(commentId);
        if (!optComment.isPresent()) {
            throw new CommentNotFoundException(commentId);
        }
        Comment comment = optComment.get();
        comment.getLikes().add(userId);
        return commentRepository.save(comment);
    }

    public Comment dislikeComment(String commentId, String userId) {
        Optional<Comment> optComment = commentRepository.findById(commentId);
        if (!optComment.isPresent()) {
            throw new CommentNotFoundException(commentId);
        }

        Comment comment = optComment.get();
        comment.getDislikes().add(userId);
        return commentRepository.save(comment);
    }

    public List<User> getLikedUsers(String commentId) {
        Optional<Comment> optComments = commentRepository.findById(commentId);
        if (!optComments.isPresent()) {
            throw new CommentNotFoundException(commentId);
        }
        List<String> userIds = optComments.get().getLikes();
        return userRepository.findAllById(userIds);
    }

    public List<User> getDisLikedUsers(String commentId) {
        Optional<Comment> optComment = commentRepository.findById(commentId);
        if (!optComment.isPresent()) {
            throw new CommentNotFoundException(commentId);
        }
        List<String> userIds = optComment.get().getDislikes();
        return userRepository.findAllById(userIds);
    }

}
