package com.intuit.tks.constants;

public class ApiConstants {

    public static final String REPLIES = "/replies";

    public static final String LIKE = "/like";

    public static final String DISLIKE = "/dislike";

    public static final String POST_COMMENT_BASE_URL = "/posts";

    public static final String POST_ID_WITH_COMMENTS = "/{postId}/comments";

    public static final String COMMENTS_ID_WITH_COMMENTS = "/comments/{commentId}";

    public static final String COMMENTS_WITH_REPLIES = COMMENTS_ID_WITH_COMMENTS + REPLIES;

    public static final String COMMENTS_WITH_LIKES = COMMENTS_ID_WITH_COMMENTS + LIKE;

    public static final String COMMENTS_WITH_DISLIKES = COMMENTS_ID_WITH_COMMENTS + DISLIKE;
}
