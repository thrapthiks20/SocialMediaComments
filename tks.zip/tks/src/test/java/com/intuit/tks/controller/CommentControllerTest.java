package com.intuit.tks.controller;

import com.intuit.tks.model.Comment;
import com.intuit.tks.model.User;
import com.intuit.tks.service.CommentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class CommentControllerTest {

    @InjectMocks
    private CommentController commentController;

    @Mock
    private CommentService commentService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testPostComment() {
        String postId = "1";
        Comment comment = new Comment();
        comment.setContent("This is a comment.");
        when(commentService.postComment(eq(postId), any(Comment.class))).thenReturn(comment);

        Comment result = commentController.postComment(postId, comment);
        assertEquals(comment, result);
        verify(commentService, times(1)).postComment(eq(postId), any(Comment.class));
    }

    @Test
    public void testGetComments() {
        String postId = "1";
        List<Comment> comments = new ArrayList<>();
        comments.add(new Comment());
        when(commentService.fetchComments(eq(postId), anyInt(), anyInt())).thenReturn(comments);

        List<Comment> result = commentController.getComments(postId, 0, 10);
        assertEquals(comments, result);
        verify(commentService, times(1)).fetchComments(eq(postId), anyInt(), anyInt());
    }

    @Test
    public void testGetReplies() {
        String commentId = "1";
        List<Comment> replies = new ArrayList<>();
        replies.add(new Comment());
        when(commentService.fetchReplies(eq(commentId), anyInt(), anyInt())).thenReturn(replies);

        List<Comment> result = commentController.getReplies(commentId, 0, 10);
        assertEquals(replies, result);
        verify(commentService, times(1)).fetchReplies(eq(commentId), anyInt(), anyInt());
    }

    @Test
    public void testLikeComment() {
        String commentId = "1";
        String userId = "user1";
        Comment comment = new Comment();
        when(commentService.likeComment(eq(commentId), eq(userId))).thenReturn(comment);

        Comment result = commentController.likeComment(commentId, userId);
        assertEquals(comment, result);
        verify(commentService, times(1)).likeComment(eq(commentId), eq(userId));
    }

    @Test
    public void testDislikeComment() {
        String commentId = "1";
        String userId = "user1";
        Comment comment = new Comment();
        when(commentService.dislikeComment(eq(commentId), eq(userId))).thenReturn(comment);

        Comment result = commentController.dislikeComment(commentId, userId);
        assertEquals(comment, result);
        verify(commentService, times(1)).dislikeComment(eq(commentId), eq(userId));
    }

    @Test
    public void testGetLikedUser() {
        String commentId = "1";
        List<User> users = new ArrayList<>();
        users.add(new User());
        when(commentService.getLikedUsers(eq(commentId))).thenReturn(users);

        List<User> result = commentController.getLikedUser(commentId);
        assertEquals(users, result);
        verify(commentService, times(1)).getLikedUsers(eq(commentId));
    }

    @Test
    public void testGetDislikedUser() {
        String commentId = "1";
        List<User> users = new ArrayList<>();
        users.add(new User());
        when(commentService.getDisLikedUsers(eq(commentId))).thenReturn(users);

        List<User> result = commentController.getDislikedUser(commentId);
        assertEquals(users, result);
        verify(commentService, times(1)).getDisLikedUsers(eq(commentId));
    }
}
