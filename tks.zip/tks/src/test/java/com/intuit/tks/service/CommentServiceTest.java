package com.intuit.tks.service;

import com.intuit.tks.model.Comment;
import com.intuit.tks.model.User;
import com.intuit.tks.repository.CommentRepository;
import com.intuit.tks.repository.PostRepository;
import com.intuit.tks.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class CommentServiceTest {

    @InjectMocks
    private CommentService commentService;

    @Mock
    private CommentRepository commentRepository;

    @Mock
    private PostRepository postRepository;

    @Mock
    private UserRepository userRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testPostComment() {
        String postId = "1";
        Comment comment = new Comment();
        comment.setContent("This is a comment.");
        comment.setPostId(postId);

        when(commentRepository.save(any(Comment.class))).thenReturn(comment);

        Comment result = commentService.postComment(postId, comment);
        assertEquals(comment, result);
        verify(commentRepository, times(1)).save(any(Comment.class));
    }

    @Test
    public void testFetchComments() {
        String postId = "1";
        List<Comment> comments = new ArrayList<>();
        comments.add(new Comment());

        when(commentRepository.findByPostId(eq(postId))).thenReturn(comments);

        List<Comment> result = commentService.fetchComments(postId, 0, 10);
        assertEquals(comments.size(), result.size());
        verify(commentRepository, times(1)).findByPostId(eq(postId));
    }

    @Test
    public void testFetchReplies() {
        String commentId = "1";
        List<Comment> replies = new ArrayList<>();
        replies.add(new Comment());

        when(commentRepository.findByParentId(eq(commentId))).thenReturn(replies);

        List<Comment> result = commentService.fetchReplies(commentId, 0, 10);
        assertEquals(replies.size(), result.size());
        verify(commentRepository, times(1)).findByParentId(eq(commentId));
    }

    @Test
    public void testLikeComment() {
        String commentId = "1";
        String userId = "user1";
        Comment comment = new Comment();
        comment.setLikes(new ArrayList<>());
        when(commentRepository.findById(eq(commentId))).thenReturn(Optional.of(comment));
        when(commentRepository.save(any(Comment.class))).thenReturn(comment);

        Comment result = commentService.likeComment(commentId, userId);
        assertNotNull(result);
        assertTrue(result.getLikes().contains(userId));
        verify(commentRepository, times(1)).save(any(Comment.class));
    }

    @Test
    public void testDislikeComment_NotFound() {
        String commentId = "1";
        String userId = "user1";

        when(commentRepository.findById(eq(commentId))).thenReturn(Optional.empty());
        Comment result = commentService.dislikeComment(commentId, userId);

        assertNull(result);
        verify(commentRepository, never()).save(any(Comment.class));
    }

    @Test
    public void testGetLikedUsers() {
        String commentId = "1";
        List<String> userIds = Arrays.asList("user1", "user2");
        Comment comment = new Comment();
        comment.setLikes(userIds);

        when(commentRepository.findById(eq(commentId))).thenReturn(Optional.of(comment));
        when(userRepository.findAllById(eq(userIds))).thenReturn(new ArrayList<>());

        List<User> result = commentService.getLikedUsers(commentId);
        assertNotNull(result);
        verify(commentRepository, times(1)).findById(eq(commentId));
        verify(userRepository, times(1)).findAllById(eq(userIds));
    }

    @Test
    public void testGetDisLikedUsers() {
        String commentId = "comment1";
        Comment comment = new Comment();
        comment.setId(commentId);
        comment.setDislikes(Arrays.asList("user1", "user2"));

        when(commentRepository.findById(commentId)).thenReturn(Optional.of(comment));
        when(userRepository.findAllById(Arrays.asList("user1", "user2")))
                .thenReturn(Arrays.asList(new User("user1", "User One"), new User("user2", "User Two"))); // Mock users

        List<User> result = commentService.getDisLikedUsers(commentId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("user1", result.get(0).getId());
        assertEquals("user2", result.get(1).getId());

        verify(commentRepository).findById(commentId);
        verify(userRepository).findAllById(Arrays.asList("user1", "user2"));
    }

}
